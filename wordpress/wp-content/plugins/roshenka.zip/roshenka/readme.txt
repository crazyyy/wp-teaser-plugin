=== Sandorik AD manager v.2 ===
Contributors: Vitali Antoniuk
Tags: teaser, ad, adware
Stable tag: 1.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0


Small ad manager plugin

== Change Log ==

= 0.1 =
* First stable release 